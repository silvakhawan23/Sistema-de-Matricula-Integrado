
from django.contrib import admin
from django.urls import path
from geral import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index_view),
    path('admin/', admin.site.urls),
    path('login/', views.login_view),
    path('logout/', views.logout_view),
    path('feed/', views.feed_view),
    path('input/', views.input_view, name='input_view'),
]
urlpatterns += static(settings.MEDIA_URL, document_root= settings.MEDIA_ROOT)
