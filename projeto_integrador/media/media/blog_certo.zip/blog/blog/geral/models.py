from django.db import models
from django.contrib.auth.models import User


class Post(models.Model):
    nome = models.CharField(max_length=20)
    titulo = models.CharField(max_length=100)
    coment = models.CharField(max_length=200)
    arq = models.FileField(upload_to="img")

    def __str__(self) -> str:
        return self.nome
       