from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponseBadRequest
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from.models import Post 
from django.http import HttpResponseRedirect,HttpResponseBadRequest,HttpResponse
from datetime import datetime
from PIL import Image
import os
from django.conf import settings


def index_view(request):
    return HttpResponseRedirect('/feed')


def login_view(request):
    if request.method == 'GET':
        return render(request, 'login.html', {
            'incorrect_login': False
        })
    elif request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return HttpResponseRedirect('/feed')
        else:
            return render(request, 'login.html', {
                'incorrect_login': True
            })  
    else:
        return HttpResponseBadRequest()


@login_required(login_url='/login')
def feed_view(request):
    dic={
        "username" : request.user.username,
        "posts": Post.objects.all()[::-1]
    }
    return render(request, 'feed.html', dic)


@login_required(login_url='/login')
def logout_view(request):
    logout(request)
    return HttpResponseRedirect('/login')

@login_required(login_url='/login')
def input_view(request):
    if request.method== 'GET':
        username = request.user.username
        return render(request, 'input.html', {
            'username': username
                 })
    elif request.method == 'POST':
        name=request.POST.get("nome")
        title= request.POST.get("titulo")
        comente= request.POST.get("coment")
        file = request.FILES.get("img")
        post=Post(nome= name,titulo=title,coment=comente,arq=file)
        post.save()
        return HttpResponseRedirect('/feed')

    

    
        

