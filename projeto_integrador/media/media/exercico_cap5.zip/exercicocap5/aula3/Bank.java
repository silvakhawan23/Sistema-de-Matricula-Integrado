

public class Bank
 {
  
    public static void main (String args [])
    {
        Banco rico = new Banco();
        rico.setNumero(10001);
        rico.setAgencia("centro"); 
        rico.setDataDeAbertura(new Data());
        rico.getDataDeAbertura().definirData(23, 03, 2004);
        rico.setNomeTitular("Khawan"); 
        rico.setSaldo(10000); 
        rico.saque(100);
        rico.depositar(30);
        System.out.println("Rendimento: "+ rico.calculaRendimento());
        System.out.println(rico.recuperaDadosParaImpressao());
        System.out.println("\n");

        //comparação de duas variavel do tipo banco 
        Banco	bank1	=	new	Banco();								
        bank1.setNomeTitular("geovana");	
        bank1.setSaldo(6700);	
        Banco	bank2	=	new	Banco();								
        bank2.setNomeTitular("danilo");
        bank2.setSaldo(540);
        if	(bank1	==	bank2)	{
                        System.out.println("iguais");
        }	else	{
                        System.out.println("diferentes");
                        System.out.println("\n");								
        }

        //atribui o valor de bank3 no bank2 e comparei
        Banco bank3 = new Banco();
        bank3.setNomeTitular("khawan"); 
        bank3.setSaldo(100); 
        bank2 = bank3;
        if	(bank3	==	bank2)	{
            System.out.println("iguais");
        }	else	{
            System.out.println("diferentes");								
            }


    }
}
