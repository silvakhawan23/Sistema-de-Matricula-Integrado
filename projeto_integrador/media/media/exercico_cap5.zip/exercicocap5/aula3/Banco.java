

public class Banco {
    private String nomeTitular;
    public String getNomeTitular() {
        return nomeTitular;
    }
    public Banco(String nome){
        this.nomeTitular=nome;

    }

    public void setNomeTitular(String nomeTitular) {
        this.nomeTitular = nomeTitular;
    }
    private int numero;
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    private String agencia;
    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }
    private double saldo;
    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    public  Data dataDeAbertura;
   
    public Data getDataDeAbertura() {
        return dataDeAbertura;
    }

    public void setDataDeAbertura(Data dataDeAbertura) {
        this.dataDeAbertura = dataDeAbertura;
    }

    public void saque (double v)
    {
        saldo = saldo - v;
        System.err.println("Valor sacado:R$ " + v  ); 
    }

   public void depositar ( double v)
    {
        saldo = saldo +v;
        System.err.println("Valor depositado:R$ " + v + "\nValor atual na conta:R$" + saldo ); 
    }
    public double calculaRendimento ( ){
        double rend;
        rend = saldo *0.1;
        return rend;
    }
     public String recuperaDadosParaImpressao(){
        String dados;
        dados = "Titular: "+ nomeTitular +"\nNumero: "+numero+"\nAgencia: "+agencia+"\nSaldo: "+saldo+"$\nData de Abertura da Conta: ";
       dados += dataDeAbertura.formatandoData(); 
       return dados;
     }
 }
